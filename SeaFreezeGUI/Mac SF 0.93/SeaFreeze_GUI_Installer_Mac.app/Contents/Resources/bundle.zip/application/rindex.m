function [newdata, indxt] = rindex(P,T, PTdata, varargin)
    %This function resets the triple points for equilibrium lines and, if
    %desired, chops the lines at the triple points. The options are:
    %'meta' for extensions, 'trunc>x' for cutting above a given (P,T) or
    %'trunc<x' for cutting below a given 'PT'. A form of 'trunc' must
    %be chosen if 'meta' is not selected. 
    
    %Finds the index of temperature through minimum of pressure and temperature through squaring and
    %addition, then replaces that value with given P and T
    [~,indxt]= min(abs((abs((PTdata(1,:)-T).^2) + abs((PTdata(2,:)-P).^2))));
    PTdata(1, indxt) = T;
    PTdata(2, indxt) = P;
    
    %Creation of varargin options, allows for metastable renditions rather
    %than truncated lines 
    options = [0,0,0];
    n= length(PTdata);
    if (~isempty(varargin))
        for c=1:length(varargin)
            switch  varargin{c}
                case {'meta'}
                    options(1) = 1;
                case  {'trunc<x'}
                    options(2) = 1;
                case  {'trunc>x'}
                    options(3) = 1;
                otherwise
                    error('Invalid argument. Check format and available options.');
            end
        end
    end
    
    %Deletes coordinates out of range if 'meta' is not chosen for precise
    %triple point representation
    if options(1)== 1
        newdata = PTdata;
    else
        if  options(3) == 1 
            PTdata(:,(indxt+1):n) = [];
            newdata = PTdata;
        elseif options(2) == 1 
            PTdata(:,1:indxt-1)=[];
            newdata = PTdata;
        else 
            error('Please choose truncate or meta extension options the given data.');
        end
    end
end


